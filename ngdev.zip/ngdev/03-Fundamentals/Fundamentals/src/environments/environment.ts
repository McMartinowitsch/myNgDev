export const environment = {
  production: false,
  title: 'ngFundamentals',
  vouchers: '/assets/vouchers.json',
  skills: '/assets/skills.json',
};
