export const environment = {
  production: true,
  title: 'ngFundamentals',
  api: '/assets/vouchers.json',
};
