export class Person {
  id: number;
  age: number;
  name: string;
  gender: string;
  married?: boolean;
  imgUrl?: string;
}
