import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ux-split',
  templateUrl: './ux-split.component.html',
  styleUrls: ['./ux-split.component.scss'],
})
export class uxSplitComponent implements OnInit {
  constructor() {}

  toolbar = '100px';

  ngOnInit() {}
}
