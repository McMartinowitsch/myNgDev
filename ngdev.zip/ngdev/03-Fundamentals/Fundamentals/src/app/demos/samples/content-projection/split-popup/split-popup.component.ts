import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-split-popup',
  templateUrl: './split-popup.component.html',
  styleUrls: ['./split-popup.component.scss'],
})
export class SplitPopupComponent implements OnInit {
  constructor() {}

  isDisabled = true;

  ngOnInit(): void {}
}
