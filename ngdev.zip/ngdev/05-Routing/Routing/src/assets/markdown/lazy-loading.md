Investigate demos-route
