Click on the button - investigate it.
Go to Skills -> click an item on the list, and notice the [state] that is passed in the button
