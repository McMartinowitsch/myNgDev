Toggle Code in pm-child.component.ts

```
ngOnInit() {
this.useSnapShot();
// this.useParamMap();
}
```
