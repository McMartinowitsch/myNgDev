import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-component-less',
  templateUrl: './component-less.component.html',
  styleUrls: ['./component-less.component.scss']
})
export class ComponentLessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
