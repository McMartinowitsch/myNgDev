import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-router-animations',
  templateUrl: './router-animations.component.html',
  styleUrls: ['./router-animations.component.scss']
})
export class RouterAnimationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
