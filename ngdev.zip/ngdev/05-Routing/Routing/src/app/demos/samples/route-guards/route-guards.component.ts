import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-route-guards',
  templateUrl: './route-guards.component.html',
  styleUrls: ['./route-guards.component.scss'],
})
export class RouteGuardsComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
