import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-router-events',
  templateUrl: './router-events.component.html',
  styleUrls: ['./router-events.component.scss']
})
export class RouterEventsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
