import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-b',
  templateUrl: './admin-b.component.html',
  styleUrls: ['./admin-b.component.scss']
})
export class AdminBComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
