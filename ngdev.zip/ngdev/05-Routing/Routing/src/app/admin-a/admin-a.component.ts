import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-a',
  templateUrl: './admin-a.component.html',
  styleUrls: ['./admin-a.component.scss']
})
export class AdminAComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
