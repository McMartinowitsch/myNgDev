export const environment = {
  production: false,
  title: 'ngRouting',
  api: '/assets/skills.json',
  markdownPath: '/assets/markdown/',
  authEnabled: false,
};
