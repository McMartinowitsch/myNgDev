# TypeScript

[TypeScript Documentation](https://www.typescriptlang.org/docs/home.html)

[MDN JavaScript Reference](https://developer.mozilla.org/en-US/docs/Web/JavaScript)

[Date /Time Manipulation - Date fns](https://date-fns.org/)

[Date fns timezone](https://github.com/prantlf/date-fns-timezone#readme)

## Extensions

[TypeScript Importer](https://marketplace.visualstudio.com/items?itemName=pmneo.tsimporter)
