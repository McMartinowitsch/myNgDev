export class MenuItem {
  label: string;
  url: string;
}
