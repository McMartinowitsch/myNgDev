export class MathFunctions {
  pi = 3.14;
  static square(nbr: number): number {
    return Math.pow(nbr, 2);
  }
}
