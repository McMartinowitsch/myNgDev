export class Calculator {
  add(a: number, b: number) {
    return a + b;
  }
}

export const constKey = 'myKey';

export function myFunction() {
  console.log('abc');
}
