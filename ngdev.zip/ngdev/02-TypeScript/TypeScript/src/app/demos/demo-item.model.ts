export class DemoItem {
  url: string;
  title: string;
  markdown?: string;
}
