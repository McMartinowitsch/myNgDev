export const environment = {
  production: true,
  title: 'Typescript',
  api: 'http://localhost:3000/',
};
