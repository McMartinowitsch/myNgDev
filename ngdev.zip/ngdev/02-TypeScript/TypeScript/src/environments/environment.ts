export const environment = {
  production: false,
  title: 'Typescript',
  api: 'http://localhost:3000/',
};
