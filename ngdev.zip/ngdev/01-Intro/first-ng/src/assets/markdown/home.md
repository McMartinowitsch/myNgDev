# Demo Home

Enter your Markdown to include in `/assets/markdown`.

[Markdown Cheat Sheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet) is a short but good introduction.

Editing Mardown in VS Code is easy using this Extension: [Markdown Shortcuts](https://marketplace.visualstudio.com/items?itemName=mdickin.markdown-shortcuts)
