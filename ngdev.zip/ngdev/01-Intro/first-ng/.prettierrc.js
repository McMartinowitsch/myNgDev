module.exports = {
  singleQuote: true,
};
