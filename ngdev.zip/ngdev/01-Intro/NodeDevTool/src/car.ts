export class Car {
  drive() {
    console.log("On the road again ... brrrrrm ....");
  }
}
