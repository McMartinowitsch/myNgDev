import * as $ from "jquery";

export class Util {
  log() {
    console.log("hello word logged from Util");
  }  
}
