# Markdown

Document your Repo using Markdown

[Intro to Markdown - Markdown Cheatsheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet)

[Auto Open Markdown](https://marketplace.visualstudio.com/items?itemName=hnw.vscode-auto-open-markdown-preview)

[Markdown Shorcuts - VS Code Extension](https://marketplace.visualstudio.com/items?itemName=mdickin.markdown-shortcuts)
