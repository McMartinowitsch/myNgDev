# Setup

Windows Setup is automated using Chocolatery.

## Chocolatery

[Chocolatery - The Package Manager for Windows](https://chocolatey.org/) can be installed using `install-chocolatery.ps1`.

Automated Windows Setup `setup-angular-dev.ps1`