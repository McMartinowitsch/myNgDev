
choco install chrome-remote-desktop-chrome -y
choco install microsoft-edge -y
choco install vscode -y
choco install microsoft-windows-terminal -y
choco install dotnetcore-sdk -y
choco install azure-cli -y
choco install azure-data-studio -y
choco install git -y
choco install gitextensions -y
choco install curl -y
choco install 7zip -y
choco install docker-desktop -y
choco install nvm -y
nvm install 10.21.0
nvm install 12.18.1
nvm use 12.18.1
npm i -g @angular/core
