# Setup

Class Setup

- Windows Dev Machine Setup located in Folder `Windows`
- Windows Subsystem Linux 2 (WSL 2) automated Setup using `setup-angular-wsl-dev.sh`

Allow Chrome to server unsafe localhost:

```
chrome://flags/#allow-insecure-localhost
```
