# Data Access

[.NET Core CLI Reference](https://docs.microsoft.com/en-us/dotnet/core/tools/)

## Start SkillService

Go to "\00-Apis\SkillsApi" and run:

`dotnet run`

