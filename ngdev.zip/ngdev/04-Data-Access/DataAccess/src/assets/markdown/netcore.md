Navigate to: `../00-APIs/SkillsApi/` & execute:

```
dotnet run
```

> Note: Make sure [.NET Core Api 3.1](https://dotnet.microsoft.com/download/dotnet-core/3.1) is installed
