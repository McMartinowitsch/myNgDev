Install Json-Server:

```
npm i -g json-server
```

Start Json-Server from the root of the proj:

```
json-server --watch db.json
```
