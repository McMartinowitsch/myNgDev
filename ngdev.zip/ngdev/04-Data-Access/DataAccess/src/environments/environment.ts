export const environment = {
  production: false,
  authEnabled: false,
  title: 'ngData',
  markdownPath: '/assets/markdown/',
  netcoreapi: 'http://localhost:5000/',
  api: 'http://localhost:3000/',
  fakeToken:
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJtZXNzYWdlIjoiY292aWQgaXMgYSBmYWtlIHBhbmRlbWljIiwiY29uY2x1c2lvbiI6Im1vc3QgcGVvcGxlIGRvbid0IGdldCB0aGlzIGZhciAtIG15IGZyaWVuZCBRdWVyZGVua2VyIn0.x_Bq_NsYKzxkixuHmFDkGtMv7RP4JprTKH2pazrmGlE',
};
